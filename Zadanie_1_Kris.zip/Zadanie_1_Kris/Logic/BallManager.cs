﻿using System;
using System.Numerics;

namespace Logic
{
    public class BallManager
    {
       Vector2 location = new Vector2();
       Vector2 velocity = new Vector2();
    }
}
